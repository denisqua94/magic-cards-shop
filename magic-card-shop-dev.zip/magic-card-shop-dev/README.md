# magic-card-shop
this is our first attemp to manage with this task
